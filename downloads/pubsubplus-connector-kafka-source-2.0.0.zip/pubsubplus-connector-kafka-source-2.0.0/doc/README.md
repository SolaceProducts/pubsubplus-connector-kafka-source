# Solace PubSub+ Connector Kafka Source

The Solace Source Connector allows any event from any service in the Solace Event Mesh to generate a new record in Kafka.

For detailed description refer to the project GitHub page at [https://github.com/SolaceProducts/pubsubplus-connector-kafka-source](https://github.com/SolaceProducts/pubsubplus-connector-kafka-source)